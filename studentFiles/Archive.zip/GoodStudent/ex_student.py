

def student_exemple_function(text):
    """
    The Corrector will import each function the student write into his file
    """
    return "Input text is %s" % (text)

def student_exemple_two(a,b):
    return a + b
